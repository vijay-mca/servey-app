import React from "react";
import ViewQuestion from "./ViewQuestion";
export default (props) => {
  return <ViewQuestion {...props} />;
};
