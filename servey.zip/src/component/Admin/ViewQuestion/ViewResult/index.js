import React from "react";
import ViewResult from "./ViewResult";

export default (props) => {
  return <ViewResult {...props} />;
};
