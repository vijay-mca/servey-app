import React from "react";
import Login from "./Login";

export default (props) => {
  return <Login {...props} />;
};
