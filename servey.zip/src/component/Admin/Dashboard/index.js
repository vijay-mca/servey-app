import React from "react";
import Dashboard from "./Dashboard";

export default (props) => {
  return <Dashboard {...props} />;
};
