import React from "react";
import CreateQuestion from "./CreateQuestion";
export default (props) => {
  return <CreateQuestion {...props} />;
};
