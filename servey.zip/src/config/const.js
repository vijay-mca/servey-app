export const API = "http://localhost:8080/api/v1/servey/";
export const REQUEST_HEADER = {
  Accept: "application/json",
  "Content-Type": "application/json",
};
