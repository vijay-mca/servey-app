export const LOGIN = "LOGIN";
export const CREATE_QUESTION = "CREATE QUESTION";
export const GET_QUESTIONS = "GET QUESTIONS";
export const VIEW_QUESTIONS = "VIEW QUESTIONS";
export const VIEW_RESULT = "VIEW RESULT";
export const OPEN_RESULT_MODAL = "OPEN RESULT MODAL";
export const LOADING = "LOADING";
export const ERROR = "ERROR";
